String Calculator - Reamdme
stringcalculator is created as Maven project configured to run with Java 7.
JUnit test scope dependency inlcuded.

Class implementing algorithm:
StringCalculator
with test:
StringCalculatorTest

Utility class:
IntegerTokenizer
with test:
TokenizerTest
